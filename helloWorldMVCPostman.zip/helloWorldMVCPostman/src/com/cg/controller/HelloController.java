package com.cg.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Message;
import com.cg.beans.Sender;

@RestController
public class HelloController {

	@RequestMapping("/")
	public String sayHello(){
		System.out.println("hii");
		return "Welcome to Spring MVC!";
		
	}
@RequestMapping("/hell")
	public Message sendMessage(String text){
		
		Message m = new Message();
		m.setText(text);
		
		Sender s = new Sender();
		s.setName("Sagar");
		m.setSender(s);
		return m;
	}
 
}



